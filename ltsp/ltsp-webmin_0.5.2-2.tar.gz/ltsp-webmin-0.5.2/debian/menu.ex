?package(ltsp-webmin):needs=X11|text|vc|wm section=Apps/see-menu-manual\
  title="ltsp-webmin" command="/usr/bin/ltsp-webmin"
