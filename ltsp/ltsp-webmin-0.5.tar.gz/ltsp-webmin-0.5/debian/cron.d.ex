#
# Regular cron jobs for the ltsp-webmin package
#
0 4	* * *	root	ltsp-webmin_maintenance
