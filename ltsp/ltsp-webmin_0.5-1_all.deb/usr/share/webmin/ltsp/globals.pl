#!/usr/bin/perl

$DEBUG = 0;
$EXPERIMENTAL = 0;

return TRUE;
